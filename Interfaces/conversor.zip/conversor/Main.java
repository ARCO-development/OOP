package conversor;

public class Main {

    public static void main(String[] args) {
        AplicacaoConverteTemperatura aplicacao = new AplicacaoConverteTemperatura();
        aplicacao.executa();
    }

}
