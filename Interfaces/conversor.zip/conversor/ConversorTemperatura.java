package conversor;

public interface ConversorTemperatura {
    public double converteTemperatura(double temperatura);
}
