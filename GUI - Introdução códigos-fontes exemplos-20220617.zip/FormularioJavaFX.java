import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class FormularioJavaFX extends Application {

    // Componentes principais
    private TextField usernameField;
    private PasswordField passField;
    private Button botao;
    private Text mensagem;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Formulario - JavaFX");

        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25, 25, 25, 25));
        //grid.setGridLinesVisible(true);

        Text formTitle = new Text("Digite os dados de login");
        formTitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
        grid.add(formTitle, 0, 0);

        Label usernameLabel = new Label("Username");
        grid.add(usernameLabel, 0, 1);

        usernameField = new TextField();
        grid.add(usernameField, 1, 1);

        Label passLabel = new Label("Password");
        grid.add(passLabel, 0, 2);

        passField = new PasswordField();
        grid.add(passField, 1, 2);

        botao = new Button("OK");
        mensagem = new Text();

        // Tratamento de evento do botao
        botao.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                mensagem.setFill(Color.RED);
                mensagem.setText("Botao 'OK' pressionado: " +
                        "Username: "+ usernameField.getText() + ", Password: " + passField.getText());
            }
        });

        HBox hbBtn = new HBox(10);
        hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
        hbBtn.getChildren().add(botao);
        grid.add(hbBtn, 1, 4);
        grid.add(mensagem, 0, 6, 2, 1);

        Scene painel = new Scene(grid,450,250);
        primaryStage.setScene(painel);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}