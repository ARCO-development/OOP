import javax.swing.*;
import java.awt.*;

public class PrimeiraJanelaSwing extends JFrame {

    // Componentes principais
    private JTextField campoTexto;
    private JButton botao;

    public PrimeiraJanelaSwing() {
        super();
        campoTexto = new JTextField(30);
        botao = new JButton("Um botao");
        FlowLayout layout = new FlowLayout();
        JPanel painel = new JPanel();
        painel.setLayout(layout);
        painel.add(campoTexto);
        painel.add(botao);
        this.add(painel);
        this.setSize(800,600);
        this.setTitle("Primeira janela Swing!");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        PrimeiraJanelaSwing janela = new PrimeiraJanelaSwing();
    }
}
