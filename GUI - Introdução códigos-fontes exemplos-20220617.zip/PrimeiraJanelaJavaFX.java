import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class PrimeiraJanelaJavaFX extends Application {

    // Componentes principais
    private TextField campoTexto;
    private Button botao;

    @Override
    public void start(Stage containerPrincipal) {
        campoTexto = new TextField();
        campoTexto.setPrefColumnCount(30);
        botao = new Button("Um botao");
        FlowPane layout = new FlowPane();
        layout.getChildren().add(campoTexto);
        layout.getChildren().add(botao);
        Scene painel = new Scene(layout, 800, 600);
        containerPrincipal.setScene(painel);
        containerPrincipal.setTitle("Primeira janela JavaFX!");
        containerPrincipal.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}
