package formulario.swing;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FormularioSwing extends JFrame {

    // Componentes principais
    private JTextField usernameField;
    private JPasswordField passField;
    private JButton botao;
    private JLabel mensagem;

    public FormularioSwing() {
        super();

        JLabel formTitle = new JLabel("Digite os dados de login");
        formTitle.setFont(new Font("Tahoma", Font.PLAIN, 20));

        GridLayout gridCampos = new GridLayout(2, 2);
        JPanel painelCampos = new JPanel(gridCampos);
        JLabel usernameLabel = new JLabel("Username");
        JLabel passLabel = new JLabel("Password");
        usernameField = new JTextField();
        passField = new JPasswordField();
        painelCampos.add(usernameLabel);
        painelCampos.add(usernameField);
        painelCampos.add(passLabel);
        painelCampos.add(passField);

        botao = new JButton("OK");
        mensagem = new JLabel();

        // Tratamento de evento do botao
        botao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mensagem.setForeground(Color.RED);
                mensagem.setText("Botao 'OK' pressionado: " +
                        "Username: "+ usernameField.getText() + ", Password: " + passField.getText());
            }
        });

        GridLayout grid = new GridLayout(4, 1);
        JPanel painel = new JPanel(grid);
        painel.add(formTitle);
        painel.add(painelCampos);
        FlowLayout botaoLayout = new FlowLayout(FlowLayout.RIGHT);
        JPanel botaoPainel = new JPanel(botaoLayout);
        botaoPainel.add(botao);
        painel.add(botaoPainel);
        painel.add(mensagem);

        this.setTitle("Formulario - Swing");
        this.add(painel);
        this.setSize(450,275);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        FormularioSwing janela = new FormularioSwing();
    }

}