public class Main {

    public static void main(String[] args) {
        Aplicacao aplic = new Aplicacao();
        aplic.executa();
    }

}
