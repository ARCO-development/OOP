package Enum;
public enum Classe {
    popular, basico, esportivo;
}