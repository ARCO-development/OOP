package Enum;
public enum Tipo {
    pessoal, empresarial;
}
