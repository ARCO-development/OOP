package objetos;

public abstract class Cobravel {

	// Atributos
	protected int identificador;
	protected String nome;
	protected double valorBase;

	// Construtor Cobravel
	public Cobravel(int identificador, String nome, double valorBase) {
		this.identificador = identificador;
		this.nome = nome;
		this.valorBase = valorBase;
	}

	/**
	 * Retorna imposto sobre valor base do item
	 * @return double imposto
	 */
	public abstract double calculaImposto();

	/**
	 * Gera formato .csv de cada item
	 * @return String csv_Object
	 */
	public abstract String toCsv();

	/**
	 * Retorna identificador do item
	 * @return int identificador
	 */
	public abstract int getID();

	/**
	 * Retorna nome do item
	 * @return String nome
	 */
	public abstract String getNome();

}
