package objetos;
import java.lang.Override;
import Enum.Tipo;

public class Servico extends Cobravel {
    
    private Tipo tipo;

    // Construtor Servico
    public Servico(int identificador, String nome, double valorBase, Tipo tipo) {
        super(identificador, nome, valorBase);
        this.tipo = tipo;
    }

    // Calcula imposto a ser pago
    @Override
    public double calculaImposto() {
        double imposto = 0;
        if (tipo == Tipo.pessoal)
        imposto = valorBase * 0.15;
        else if (tipo == Tipo.empresarial)
        imposto = valorBase * 0.30;
        return imposto;
    }

    @Override
    public String toString() {
        String format;
        format  = "\nSERVIÇO\n" + 
        "----------------------------------------\n" +
        "ID: " + identificador + "\n" +
        "Nome: " + nome + "\n" + 
        "Tipo: " + tipo + "\n" +
        "ValorBase: " + valorBase + "\n";
        return format;
    }

    @Override
    public int getID() {
        return identificador;
    }

    @Override
    public String getNome() {
        return nome;
    }

    // Objeto para arquivo .csv
    @Override
    public String toCsv() {
        String csvString = "Servico;" + identificador + ";" + nome + ";" + valorBase + ";" + tipo;
        return csvString;
    }

}
