package objetos;
import java.lang.Override;
import Enum.Classe;

public class Veiculo extends Cobravel {
    
    private Classe classe;

    // Construtor Veiculo
    public Veiculo(int identificador, String nome, double valorBase, Classe classe) {
        super(identificador, nome, valorBase);
        this.classe = classe;
    }

    // Calcula imposto a ser pago
    @Override
    public double calculaImposto() {
        if (classe == Classe.popular)
        return valorBase * 0.05;
        else if (classe == Classe.basico)
        return valorBase * 0.20; 
        return valorBase * 0.50;
    }

    @Override
    public String toString() {
        String format;
        format  = "\nVEÍCULO\n" +
        "----------------------------------------\n" +
        "ID: " + identificador + "\n" +
        "Nome: " + nome + "\n" + 
        "Classe: " + classe + "\n" +
        "ValorBase: " + valorBase + "\n";
        return format;
    }

    @Override
    public int getID() {
        return identificador;
    }

    @Override
    public String getNome() {
        return nome;
    }

    // Objeto para arquivo .csv
    @Override
    public String toCsv() {
        String csvString = "Veiculo;" + identificador + ";" + nome + ";" + valorBase + ";" + classe;
        return csvString;
    }

}
