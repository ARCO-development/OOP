import App.ACMEFinancas;

public class Main {

	public static void main(String[] args) {

		ACMEFinancas app = new ACMEFinancas();
		app.inicializa();
		app.executa();
	}

}
