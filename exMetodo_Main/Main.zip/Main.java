public class Main {

    public static void main (String[] args) {    
        
        int length = args.length;
        
        if (length != 3) {
            System.out.println("digite os valores do dividendo, divisor e precisao na ordem descrita.");
        }
        else {
            String divid = args[0];
            String divis = args[1];
            String pres = args[2];
            String result = Matematica.divisao(divid, divis, pres);
            System.out.println("dividendo: " + divid  + ", divisor: "+ divis + ", precisao: " + pres + ", string de retorno: " + result);
        }
    }

    public class Matematica {
        
        public static String divisao(String dividendo, String divisor, String precisao) {
            
            int dividendoInt = Integer.parseInt(dividendo);
            int divisorInt = Integer.parseInt(divisor);
            int precisaoInt = Integer.parseInt(precisao);
            
            if ((dividendoInt > 0 || dividendoInt < 0) && divisorInt == 0) {
                return "Nao foi possivel realizar a divisao";
            }
            else {
                double result = dividendoInt / (double)divisorInt;
                String stringResult = String.valueOf(result);
                int count = 0;
                
                for (int i = 0; i < stringResult.length(); i++) {
                    if (stringResult.charAt(i) != '.') {
                        count++;
                    }
                    else {
                        break;
                    } 
                }
                if (result % 2 != 0) {
                    stringResult = stringResult.substring(0, count + 1 + precisaoInt);
                    return stringResult;  
                }
                else {
                    return stringResult;  
                }    
            }
        }

        public 
    }


}


