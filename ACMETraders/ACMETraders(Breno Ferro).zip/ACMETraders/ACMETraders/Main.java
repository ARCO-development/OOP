package ACMETraders;
import app.ACMETraders;

public class Main {

	public static void main(String[] args) {

		ACMETraders app = new ACMETraders();
		app.preCadastrar();

	} 

}
