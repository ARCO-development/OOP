package objetos;

public class Receita implements Comparable<Receita>{

    // Attributes
    private int numReceita;
    private String data_extracao;
    private String ano;
    private String mes;
    private String cod_orgao;
    private String nome_orgao;
    private String cod_categoria;
    private String nome_categoria;
    private String cod_origem;
    private String nome_origem;
    private String cod_especie;
    private String nome_especie;
    private String cod_desdobramento1;
    private String nome_desdobramento1;
    private String cod_tipo;
    private String nome_tipo;
    private String valor_arrecadado;
    private String valor_orcado;

    // Constructor
    public Receita(int numReceita,String data_extracao,String ano,String mes,String cod_orgao,String nome_orgao,String cod_categoria,String nome_categoria,String cod_origem,String nome_origem,String cod_especie,String nome_especie,String cod_desdobramento1,String nome_desdobramento1,String cod_tipo,String nome_tipo,String valor_arrecadado,String valor_orcado) {

        this.numReceita = numReceita;
        this.data_extracao = data_extracao;
        this.ano = ano;
        this.mes = mes;
        this.cod_orgao = cod_orgao;
        this.nome_orgao = nome_orgao;
        this.cod_categoria = cod_categoria;
        this.nome_categoria = nome_categoria;
        this.cod_origem = cod_origem;
        this.nome_origem = nome_origem;
        this.cod_especie = cod_especie;
        this.nome_especie = nome_especie;
        this.cod_desdobramento1 = cod_desdobramento1;
        this.nome_desdobramento1 = nome_desdobramento1;
        this.cod_tipo = cod_tipo;
        this.nome_tipo = nome_tipo;
        this.valor_arrecadado = valor_arrecadado;
        this.valor_orcado = valor_orcado;
    }

    // Methods
    public String getDataExtracao() {
        return data_extracao;
    }

    public String getAno() {
        return ano;
    }

    public String getMes() {
        return mes;
    }

    public String getCodOrgao() {
        return cod_orgao;
    }

    public String getNomeOrgao() {
        return nome_orgao;
    }

    public String getCodCategoria() {
        return cod_categoria;
    }

    public String getNomeCategoria() {
        return nome_categoria;
    }

    public String getCodOrigem() {
        return cod_origem;
    }

    public String getNomeOrigem() {
        return nome_origem;
    }

    public String getCodEspecie() {
        return cod_especie;
    }

    public String getNomeEspecie() {
        return nome_especie;
    }

    public String getCodDesdobramento1() {
        return cod_desdobramento1;
    }

    public String getNomeDesdobramento1() {
        return nome_desdobramento1;
    }

    public String getCodTipo() {
        return cod_tipo;
    }

    public String getNomeTipo() {
        return nome_tipo;
    }

    public String getValorArrecadado() {
        return valor_arrecadado;
    }

    public String getValorOrcado() {
        return valor_orcado;
    }

    public int getNumReceita() {
        return numReceita;
    }

    public void setNumReceita(int num) {
        numReceita = num;
    }



    @Override
    public String toString() {
        String format = "";
        format = "\nReceita " + "#" + this.numReceita + "---------------------------------------------\n" +
                 "\nData: " + this.data_extracao +
                 "\nOrgão: " + this.nome_orgao +
                 "\nCategoria: " + this.nome_categoria +
                 "\nOrigem: " + this.nome_origem +
                 "\nEspecie " + this.nome_especie +
                 "\nDesdobramento: " + this.nome_desdobramento1 +
                 "\nTipo: " + this.nome_tipo +
                 "\nValor arrecadado: " + this.valor_arrecadado;
        return format;
    }

    public String toCsv() {
        String formatCsv = "";
        formatCsv =
        data_extracao + ";" + ano + ";" + mes + ";" + cod_orgao + ";" + nome_orgao + ";" + cod_categoria + ";" +
        nome_categoria + ";" + cod_origem + ";" + nome_origem + ";" + cod_especie + ";" + nome_especie + ";" + cod_desdobramento1 + ";" +
        nome_desdobramento1 + ";" + cod_tipo + ";" + nome_tipo + ";" + valor_arrecadado + ";" + valor_orcado + "\n";
        return formatCsv;
    }

    @Override
    public int compareTo(Receita anotherReceita) {
        // MENOR PELO ANO ---
        if (this.getAno().compareTo(anotherReceita.getAno()) < 0)
        {
            return -1;
        }
        // MENOR PELO MES ----
        else if (this.getAno().compareTo(anotherReceita.getAno()) == 0 && this.getDataExtracao().substring(5, 7).compareTo(anotherReceita.getDataExtracao().substring(5, 7)) < 0)
        {
            return -1;
        }
        // MENOR PELO DIA ---------
        else if (this.getAno().compareTo(anotherReceita.getAno()) == 0 && this.getDataExtracao().substring(5, 7).compareTo(anotherReceita.getDataExtracao().substring(5, 7)) == 0 && this.getDataExtracao().substring(8, 10).compareTo(anotherReceita.getDataExtracao().substring(8, 10)) < 0)
        {
            return -1;
        }
        // TUDO IGUAL
        else if (this.getAno().compareTo(anotherReceita.getAno()) == 0 && this.getDataExtracao().substring(5, 7).compareTo(anotherReceita.getDataExtracao().substring(5, 7)) == 0 && this.getDataExtracao().substring(8, 10).compareTo(anotherReceita.getDataExtracao().substring(8, 10)) == 0)
        {
            return 0;
        }
        // MAIOR PELO ANO ---
        else if (this.getAno().compareTo(anotherReceita.getAno()) > 0)
        {
            return 1;
        }
        // MAIOR PELO MES ----
        else if (this.getAno().compareTo(anotherReceita.getAno()) == 0 && this.getDataExtracao().substring(5, 7).compareTo(anotherReceita.getDataExtracao().substring(5, 7)) > 0)
        {
            return 1;
        }
        // MAIOR PELO DIA ----------
        else
        {
            return 1;
        }

    }
}
