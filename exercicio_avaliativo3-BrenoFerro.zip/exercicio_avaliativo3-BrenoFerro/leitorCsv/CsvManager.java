package leitorCsv;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import objetos.Receita;

public class CsvManager {

    // Attributes
    private BufferedReader reader;
    private BufferedWriter writer;

    // Methods
    public boolean open(String path) {
        try {
            reader = new BufferedReader(new FileReader(path));
        } catch (FileNotFoundException e) {
            System.out.println(":( Error: could not open file");
            e.printStackTrace();
            return false;
        }
        return true;
    }


    public boolean readToMemory(ArrayList<Receita> array) {
        String line = "";
        try {
            while ((line = reader.readLine()) != null)
            {
                String[] values = line.split(";");
                // Instanciar objetos em memoria
                Receita receita = new Receita(array.size(), values[0], values[1], values[2], values[3], values[4], values[5], values[6], values[7], values[8], values[9], values[10], values[11], values[12], values[13], values[14], values[15], values[16]);
                array.add(receita);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println(":( Error: could not read file");
            e.printStackTrace();
            return false;
        }
        return true;
    }


    public boolean saveCsv(String filename) {
        try {
            writer = new BufferedWriter(new FileWriter("./csv/" + filename + ".csv"));
        } catch (FileNotFoundException e) {
            System.out.println(":( Error: could not save file");
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            System.out.println(":( Error: could not save file");
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean appendObject(String csvObject) {
        try {
            writer.append(csvObject);
        } catch (IOException e) {
            System.out.println(":( Could not append data to file");
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public void closeWriter() {
        try {
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}