package dados;

import java.util.ArrayList;
import java.util.Collections;

import leitorCsv.CsvManager;
import objetos.Receita;

public class Cadastro {

    // Attributes
    private ArrayList<Receita> dados = new ArrayList<>();
    private CsvManager csv = new CsvManager();
    private int countNextDado = 0;

    // Methods
    public boolean carregar_dados_abertos(String path) {
        if (csv.open("./csv/" + path + ".csv"))
        {
            if (csv.readToMemory(dados))
            {
                return true;
            }
        }
        return false;
    }


    public ArrayList<Receita> classificar_dados_por_data_crescente() {
        Collections.sort(dados);
        return dados;
    }


    public ArrayList<Receita> classificar_dados_por_data_descrescente() {
        Collections.sort(dados);
        Collections.reverse(dados);
        return dados;
    }


    public String getNextDado() {
        String dado = null;
        dado = dados.get(countNextDado).toString();
        countNextDado++;
        return dado;
    }


    public ArrayList<Receita> consultar_dados_por_data(String date) {
        ArrayList<Receita> arrayPesquisa = new ArrayList<>();
        for (int i = 0; i < dados.size(); i++)
        {
            if (dados.get(i).getDataExtracao().contains(date))
            {
                arrayPesquisa.add(dados.get(i));
            }
        }
        return arrayPesquisa;
    }


    public boolean salvar_dados_em_arquivo(String filename) {
        String csvObject = null;
        if (!csv.saveCsv(filename))
        {
            return false;
        }
        for (int i = 0; i < dados.size(); i++)
        {
            csvObject = dados.get(i).toCsv();
            csv.appendObject(csvObject);
        }
        csv.closeWriter();
        return true;
    }

    public int size() {
        return dados.size();
    }

    public void setCountNextDadoToOne() {
        countNextDado = 1;
    }

    public void emptyList() {
        dados.clear();
    }


}